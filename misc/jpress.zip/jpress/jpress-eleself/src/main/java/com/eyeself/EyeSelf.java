package com.eyeself;

public class EyeSelf {

	public static final String MODULE_PRODUCT = "product";
	public static final String MODULE_BUSINESS = "business";

}
