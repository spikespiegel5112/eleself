package com.eyeself.pay.alipay;

public class Alipay {

}
