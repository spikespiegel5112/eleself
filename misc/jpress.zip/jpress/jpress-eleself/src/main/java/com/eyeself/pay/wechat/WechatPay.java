package com.eyeself.pay.wechat;

public class WechatPay {

}
